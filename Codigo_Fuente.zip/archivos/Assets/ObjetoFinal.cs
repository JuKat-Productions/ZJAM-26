using UnityEngine;
using UnityEngine.InputSystem;

public class ObjetoFinal : MonoBehaviour
{
    private bool jugadorCerca = false;
    private GerenteFinal gerenteFinal;

    private void Start()
    {
        gerenteFinal = FindObjectOfType<GerenteFinal>();
    }

    private void Update()
    {
        if (jugadorCerca && Keyboard.current != null && Keyboard.current.eKey.wasPressedThisFrame)
        {
            if (gerenteFinal != null)
            {
                gerenteFinal.AbrirMenuOpciones();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player")) 
        {
            jugadorCerca = true;
            Debug.Log("Presiona E para acusar al culpable.");
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            jugadorCerca = false;
        }
    }
}