using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuPrincipal : MonoBehaviour
{
    [SerializeField] private string nombreEscenaIntroduccion = "Introduccion";
    
    [SerializeField] private GameObject menuPrincipalGO;
    [SerializeField] private GameObject panelInstruccionesGO;

    public void JugarJuego()
    {
        SceneManager.LoadScene(nombreEscenaIntroduccion);
    }

    public void MostrarInstrucciones()
    {
        menuPrincipalGO.SetActive(false);
        panelInstruccionesGO.SetActive(true);
    }

    public void VolverAlMenu()
    {
        menuPrincipalGO.SetActive(true);
        panelInstruccionesGO.SetActive(false);
    }

    public void SalirDelJuego()
    {
        Debug.Log("El jugador ha salido del juego.");
        Application.Quit();
    }
}