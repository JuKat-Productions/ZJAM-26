using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class casa1 : MonoBehaviour
{
    [System.Serializable]
    public class OpcionDialogo
    {
        public string textoBoton;
        public NodoDialogo siguienteNodo; 
    }

    [System.Serializable]
    public class NodoDialogo
    {
        [Header("Contenido del Dialogo")]
        [TextArea(3, 10)]
        public List<string> lineasDeTexto;

        [Header("Opciones al terminar el texto")]
        public List<OpcionDialogo> opcionesJugador;
    }

    [Header("Dialogo Inicial del NPC")]
    public NodoDialogo dialogoInicial;

    [Header("Imagen unica del NPC")]
    public Sprite retratoFijoEsteNPC;
    [TextArea(2, 5)]
    public string dialogoYaInteractuado = "Ya te dije todo lo que sé. Déjame en paz.";
    private bool yaHabloConElJugador = false; 

    [Header("Configuracion de UI (texto)")]
    public GameObject objetoCuadroDialogo;
    public TextMeshProUGUI componenteTexto;
    public Transform contenedorBotones;
    public GameObject prefabBotonOpcion;

    [Header("Componentes de UI (retratos)")]
    public Image imagenUIProta;
    public Image imagenUINPC;
    public Sprite retratoProtaPorDefecto;

    private static bool algunDialogoActivoEnElJuego = false;
    private static casa1 npcHablandoActualmente = null;

    private bool jugadorCerca = false;
    private bool mostrandoOpciones = false;
    
    private NodoDialogo nodoActual;
    private int indiceLineaActual = 0;
    private bool mostrandoDialogoRepetido = false; 

    void Update()
    {
        if (jugadorCerca && Keyboard.current != null && Keyboard.current.eKey.wasPressedThisFrame)
        {
            if (!algunDialogoActivoEnElJuego)
            {
                if (!yaHabloConElJugador)
                {
                    MostrarDialogoInicial();
                }
                else
                {
                    MostrarDialogoRepetido();
                }
            }
            else if (npcHablandoActualmente == this)
            {
                if (mostrandoDialogoRepetido)
                {
                    OcultarDialogo();
                }
                else if (!mostrandoOpciones)
                {
                    AvanzarDialogo();
                }
            }
        }
    }

    void MostrarDialogoInicial()
    {
        if (dialogoInicial == null || dialogoInicial.lineasDeTexto.Count == 0) return;

        algunDialogoActivoEnElJuego = true;
        npcHablandoActualmente = this;
        mostrandoOpciones = false;
        mostrandoDialogoRepetido = false;
        
        nodoActual = dialogoInicial;
        indiceLineaActual = 0;

        objetoCuadroDialogo.SetActive(true);
        LimpiarBotonesAnteriores();
        MostrarLineaActual();
        EstablecerRetratosFijos();
    }

    void MostrarDialogoRepetido()
    {
        if (string.IsNullOrEmpty(dialogoYaInteractuado)) return;

        algunDialogoActivoEnElJuego = true;
        npcHablandoActualmente = this;
        mostrandoOpciones = false;
        mostrandoDialogoRepetido = true;

        objetoCuadroDialogo.SetActive(true);
        LimpiarBotonesAnteriores();

        if (componenteTexto != null)
        {
            componenteTexto.gameObject.SetActive(true);
            componenteTexto.text = dialogoYaInteractuado;
        }

        EstablecerRetratosFijos();
    }

    void MostrarLineaActual()
    {
        if (componenteTexto != null)
        {
            componenteTexto.gameObject.SetActive(true);
            componenteTexto.text = nodoActual.lineasDeTexto[indiceLineaActual];
        }
    }

    void EstablecerRetratosFijos()
    {
        if (imagenUIProta != null && retratoProtaPorDefecto != null)
        {
            imagenUIProta.gameObject.SetActive(true);
            imagenUIProta.sprite = retratoProtaPorDefecto;
        }

        if (imagenUINPC != null && retratoFijoEsteNPC != null)
        {
            imagenUINPC.gameObject.SetActive(true);
            imagenUINPC.sprite = retratoFijoEsteNPC;
        }
    }

    void AvanzarDialogo()
    {
        indiceLineaActual++;

        if (indiceLineaActual < nodoActual.lineasDeTexto.Count)
        {
            MostrarLineaActual();
        }
        else
        {
            if (nodoActual.opcionesJugador != null && nodoActual.opcionesJugador.Count > 0)
            {
                CrearBotonesOpciones();
            }
            else
            {
                yaHabloConElJugador = true;
                OcultarDialogo();
            }
        }
    }

    void CrearBotonesOpciones()
    {
        mostrandoOpciones = true;
        
        if (componenteTexto != null)
        {
            componenteTexto.text = ""; 
            componenteTexto.gameObject.SetActive(false);
        }

        LimpiarBotonesAnteriores();

        foreach (OpcionDialogo opcion in nodoActual.opcionesJugador)
        {
            GameObject nuevoBoton = Instantiate(prefabBotonOpcion, contenedorBotones);
            nuevoBoton.GetComponentInChildren<TextMeshProUGUI>().text = opcion.textoBoton;
            nuevoBoton.GetComponent<Button>().onClick.AddListener(() => SeleccionarOpcion(opcion.siguienteNodo));
        }
    }

    void SeleccionarOpcion(NodoDialogo siguienteNodo)
    {
        LimpiarBotonesAnteriores();
        mostrandoOpciones = false;

        if (siguienteNodo == null || siguienteNodo.lineasDeTexto.Count == 0)
        {
            yaHabloConElJugador = true;
            OcultarDialogo();
        }
        else
        {
            nodoActual = siguienteNodo;
            indiceLineaActual = 0;
            MostrarLineaActual();
            EstablecerRetratosFijos(); 
        }
    }

    void LimpiarBotonesAnteriores()
    {
        foreach (Transform hijo in contenedorBotones)
        {
            Destroy(hijo.gameObject);
        }
    }

    public void OcultarDialogo()
    {
        algunDialogoActivoEnElJuego = false;
        npcHablandoActualmente = null;
        mostrandoOpciones = false;
        mostrandoDialogoRepetido = false;
        nodoActual = null;
        indiceLineaActual = 0;
        LimpiarBotonesAnteriores();
        
        if (componenteTexto != null) componenteTexto.text = "";
        if (imagenUIProta != null) imagenUIProta.gameObject.SetActive(false);
        if (imagenUINPC != null) imagenUINPC.gameObject.SetActive(false);

        objetoCuadroDialogo.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") || other.gameObject.name == "personaje")
        {
            jugadorCerca = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player") || other.gameObject.name == "personaje")
        {
            jugadorCerca = false;
            if (npcHablandoActualmente == this)
            {
                OcultarDialogo();
            }
        }
    }
}