using UnityEngine;
using UnityEngine.InputSystem;

public class MovimientoPersonaje : MonoBehaviour
{
    [Header("Configuración de Movimiento")]
    public float velocidad = 5f;

    [Header("Sprites")]
    public Sprite spriteQuieto;
    public Sprite spritePaso;

    [Header("Velocidad de Animación")]
    public float tiempoPorCuadro = 0.2f;

    private Rigidbody2D rb;
    private SpriteRenderer spriteRenderer;
    private float inputX;
    
    private float temporizadorAnimacion;
    private bool mostrarSpriteQuieto = true;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();

        if (spriteQuieto != null) spriteRenderer.sprite = spriteQuieto;
    }

    void Update()
    {
        if (Keyboard.current != null)
        {
            inputX = (Keyboard.current.dKey.isPressed ? 1 : 0) - (Keyboard.current.aKey.isPressed ? 1 : 0);
            
            if (inputX == 0)
            {
                inputX = (Keyboard.current.rightArrowKey.isPressed ? 1 : 0) - (Keyboard.current.leftArrowKey.isPressed ? 1 : 0);
            }
        }

        if (inputX != 0)
        {
            spriteRenderer.flipX = (inputX > 0);

            if (temporizadorAnimacion == 0f)
            {
                mostrarSpriteQuieto = false; 
                spriteRenderer.sprite = spritePaso;
            }

            temporizadorAnimacion += Time.deltaTime;
            if (temporizadorAnimacion >= tiempoPorCuadro)
            {
                mostrarSpriteQuieto = !mostrarSpriteQuieto;
                temporizadorAnimacion = 0.001f;
                
                spriteRenderer.sprite = mostrarSpriteQuieto ? spriteQuieto : spritePaso;
            }
        }
        else
        {
            spriteRenderer.sprite = spriteQuieto;
            temporizadorAnimacion = 0f;
            mostrarSpriteQuieto = true;
        }

    }

    void FixedUpdate()
    {
        Vector2 movimiento = new Vector2(inputX * velocidad, rb.linearVelocity.y);
        rb.linearVelocity = movimiento;
    }
}