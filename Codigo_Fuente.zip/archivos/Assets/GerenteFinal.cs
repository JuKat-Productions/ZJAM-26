using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class GerenteFinal : MonoBehaviour
{
    [Header("Configuración de UI")]
    public GameObject menuCulpablesUI;

    [Header("Pantalla de resultado final")]
    public GameObject pantallaResultadoUI;
    public TextMeshProUGUI textoResultadoComponente;
    
    [Tooltip("El componente Image muestra la ilustración del final correcto.")]
    public Image imagenResultadoComponente; 
    
    [Tooltip("Sprite de la imagen especial.")]
    public Sprite imagenFinalCorrecto;

    [Header("Textos de los Finales")]
    [TextArea(5, 12)]
    public string[] historiasDeFinal;

    [Header("Configuración de Retorno")]
    [SerializeField] private string nombreEscenaMenu = "MenuInicial";

    private bool finalMostrado = false;
    
    private bool esFinalCorrecto = false;
    private int faseFinal = 0; 

    void Update()
    {
        if (finalMostrado)
        {
            if ((Keyboard.current != null && Keyboard.current.anyKey.wasPressedThisFrame) ||
                (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame))
            {
                AvanzarEnPantallaFinal();
            }
        }
    }

    void AvanzarEnPantallaFinal()
    {
        if (esFinalCorrecto)
        {
            if (faseFinal == 0)
            {
                if (textoResultadoComponente != null) textoResultadoComponente.gameObject.SetActive(false);
                if (imagenResultadoComponente != null) imagenResultadoComponente.gameObject.SetActive(true);
                
                faseFinal = 1;
            }
            else if (faseFinal == 1)
            {
                Time.timeScale = 1f; 
                SceneManager.LoadScene(nombreEscenaMenu);
            }
        }
        else
        {
            Time.timeScale = 1f; 
            SceneManager.LoadScene(nombreEscenaMenu);
        }
    }

    public void AbrirMenuOpciones()
    {
        if (menuCulpablesUI != null)
        {
            menuCulpablesUI.SetActive(true); 
            Time.timeScale = 0f;
        }
    }

    public void ElegirCulpable(int numeroSospechoso)
    {
        menuCulpablesUI.SetActive(false);

        pantallaResultadoUI.SetActive(true);
        finalMostrado = true;
        faseFinal = 0; 

        esFinalCorrecto = (numeroSospechoso == 4);

        int indiceLista = numeroSospechoso - 1;

        if (indiceLista >= 0 && indiceLista < historiasDeFinal.Length)
        {
            textoResultadoComponente.text = historiasDeFinal[indiceLista];
        }
        else
        {
            textoResultadoComponente.text = "Error: No escrito la historia para el sospechoso " + numeroSospechoso + " en el Inspector.";
        }

        if (imagenResultadoComponente != null)
        {
            imagenResultadoComponente.gameObject.SetActive(false); 
            if (textoResultadoComponente != null) textoResultadoComponente.gameObject.SetActive(true);

            if (esFinalCorrecto && imagenFinalCorrecto != null)
            {
                imagenResultadoComponente.sprite = imagenFinalCorrecto;
            }
        }

        if (esFinalCorrecto)
        {
            Debug.Log("¡Elección correcta!");
        }
        else
        {
            Debug.Log("Elección incorrecta.");
        }
    }
}